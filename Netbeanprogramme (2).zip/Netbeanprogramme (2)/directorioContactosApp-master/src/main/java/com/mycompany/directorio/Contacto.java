/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.directorio;

import java.util.ArrayList;

/**
 *
 * @author Katherine Ospina
 */
public class Contacto {
    
    String nombre;// Atributo de la clase 
    String telefono;
    String direccionpostal;
    String correoelectronico; 
    
    //Llamamos al constructor
    
    public Contacto( String nombrec, String telefono,String direccionpostal,String correoelectronico){
        
         this.nombre = nombrec; //Asignar al atributo de clase la variable local
         this.telefono = telefono;
         this.direccionpostal = direccionpostal;
         this.correoelectronico = correoelectronico;
        
    }
    
    public Contacto (){
        
        
    
    
    
        
    }
}
